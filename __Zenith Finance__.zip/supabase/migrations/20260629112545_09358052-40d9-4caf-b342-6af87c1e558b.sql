
-- PROFILES
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  display_name text,
  avatar_url text,
  goal text check (goal in ('wealth','markets','exams')),
  daily_goal_minutes int default 5,
  xp int default 0,
  level int default 1,
  streak_count int default 0,
  streak_last_date date,
  streak_freeze_count int default 1,
  created_at timestamptz default now()
);
grant select, insert, update, delete on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;
create policy "profiles_select_all_auth" on public.profiles for select to authenticated using (true);
create policy "profiles_update_own" on public.profiles for update to authenticated using (auth.uid() = id);
create policy "profiles_insert_own" on public.profiles for insert to authenticated with check (auth.uid() = id);

-- auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email,'@',1)))
  on conflict (id) do nothing;
  return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users
for each row execute function public.handle_new_user();

-- CONCEPTS
create table public.concepts (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  title text not null,
  description text,
  domain text not null,
  order_index int default 0,
  created_at timestamptz default now()
);
grant select on public.concepts to authenticated, anon;
grant all on public.concepts to service_role;
alter table public.concepts enable row level security;
create policy "concepts_read" on public.concepts for select using (true);

-- LESSONS
create table public.lessons (
  id uuid primary key default gen_random_uuid(),
  concept_id uuid references public.concepts(id) on delete cascade,
  title text not null,
  slug text unique not null,
  cards jsonb not null,
  xp_reward int default 20,
  order_index int default 0,
  is_published boolean default true,
  created_at timestamptz default now()
);
grant select on public.lessons to authenticated, anon;
grant all on public.lessons to service_role;
alter table public.lessons enable row level security;
create policy "lessons_read" on public.lessons for select using (true);

-- QUIZZES
create table public.quizzes (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid references public.lessons(id) on delete cascade unique,
  questions jsonb not null,
  xp_reward int default 30,
  pass_threshold int default 70,
  created_at timestamptz default now()
);
grant select on public.quizzes to authenticated, anon;
grant all on public.quizzes to service_role;
alter table public.quizzes enable row level security;
create policy "quizzes_read" on public.quizzes for select using (true);

-- SIMULATIONS
create table public.simulations (
  id uuid primary key default gen_random_uuid(),
  concept_id uuid references public.concepts(id) on delete cascade,
  title text not null,
  scenario text not null,
  choices jsonb not null,
  xp_reward int default 40,
  created_at timestamptz default now()
);
grant select on public.simulations to authenticated, anon;
grant all on public.simulations to service_role;
alter table public.simulations enable row level security;
create policy "simulations_read" on public.simulations for select using (true);

-- USER LESSON PROGRESS
create table public.user_lesson_progress (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  lesson_id uuid references public.lessons(id) on delete cascade,
  status text check (status in ('available','in_progress','completed','mastered')) default 'available',
  card_index int default 0,
  completed_at timestamptz,
  unique(user_id, lesson_id)
);
grant select, insert, update, delete on public.user_lesson_progress to authenticated;
grant all on public.user_lesson_progress to service_role;
alter table public.user_lesson_progress enable row level security;
create policy "ulp_own" on public.user_lesson_progress for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- USER QUIZ RESULTS
create table public.user_quiz_results (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  quiz_id uuid references public.quizzes(id) on delete cascade,
  score int not null,
  passed boolean not null,
  answers jsonb,
  completed_at timestamptz default now()
);
grant select, insert, update, delete on public.user_quiz_results to authenticated;
grant all on public.user_quiz_results to service_role;
alter table public.user_quiz_results enable row level security;
create policy "uqr_own" on public.user_quiz_results for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- USER SIMULATION RESULTS
create table public.user_simulation_results (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  simulation_id uuid references public.simulations(id) on delete cascade,
  choice_index int not null,
  completed_at timestamptz default now()
);
grant select, insert, update, delete on public.user_simulation_results to authenticated;
grant all on public.user_simulation_results to service_role;
alter table public.user_simulation_results enable row level security;
create policy "usr_own" on public.user_simulation_results for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- CONCEPT MASTERY
create table public.user_concept_mastery (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  concept_id uuid references public.concepts(id) on delete cascade,
  mastery_level int default 1 check (mastery_level between 1 and 5),
  next_review_date date,
  unique(user_id, concept_id)
);
grant select, insert, update, delete on public.user_concept_mastery to authenticated;
grant all on public.user_concept_mastery to service_role;
alter table public.user_concept_mastery enable row level security;
create policy "ucm_own" on public.user_concept_mastery for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- XP TRANSACTIONS
create table public.xp_transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  amount int not null,
  source text not null,
  reference_id uuid,
  created_at timestamptz default now()
);
grant select, insert on public.xp_transactions to authenticated;
grant all on public.xp_transactions to service_role;
alter table public.xp_transactions enable row level security;
create policy "xp_own_sel" on public.xp_transactions for select to authenticated using (auth.uid() = user_id);
create policy "xp_own_ins" on public.xp_transactions for insert to authenticated with check (auth.uid() = user_id);

-- BADGES
create table public.badges (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  description text,
  icon text
);
grant select on public.badges to authenticated, anon;
grant all on public.badges to service_role;
alter table public.badges enable row level security;
create policy "badges_read" on public.badges for select using (true);

create table public.user_badges (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  badge_id uuid references public.badges(id) on delete cascade,
  earned_at timestamptz default now(),
  unique(user_id, badge_id)
);
grant select, insert, delete on public.user_badges to authenticated;
grant all on public.user_badges to service_role;
alter table public.user_badges enable row level security;
create policy "ub_own_sel" on public.user_badges for select to authenticated using (auth.uid() = user_id);
create policy "ub_own_ins" on public.user_badges for insert to authenticated with check (auth.uid() = user_id);

-- NEWS
create table public.news_articles (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  summary text not null,
  why_it_matters text,
  source_url text,
  concept_id uuid references public.concepts(id) on delete set null,
  published_at timestamptz default now()
);
grant select on public.news_articles to authenticated, anon;
grant all on public.news_articles to service_role;
alter table public.news_articles enable row level security;
create policy "news_read" on public.news_articles for select using (true);

-- DAILY CHALLENGES
create table public.daily_challenges (
  id uuid primary key default gen_random_uuid(),
  challenge_date date unique not null,
  lesson_id uuid references public.lessons(id) on delete set null,
  quiz_id uuid references public.quizzes(id) on delete set null,
  xp_reward int default 50
);
grant select on public.daily_challenges to authenticated, anon;
grant all on public.daily_challenges to service_role;
alter table public.daily_challenges enable row level security;
create policy "dc_read" on public.daily_challenges for select using (true);

create table public.user_daily_challenges (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  challenge_id uuid references public.daily_challenges(id) on delete cascade,
  completed_at timestamptz default now(),
  unique(user_id, challenge_id)
);
grant select, insert on public.user_daily_challenges to authenticated;
grant all on public.user_daily_challenges to service_role;
alter table public.user_daily_challenges enable row level security;
create policy "udc_own_sel" on public.user_daily_challenges for select to authenticated using (auth.uid() = user_id);
create policy "udc_own_ins" on public.user_daily_challenges for insert to authenticated with check (auth.uid() = user_id);

-- LEAGUES
create table public.leagues (
  id uuid primary key default gen_random_uuid(),
  tier text check (tier in ('bronze','silver','gold','sapphire','amethyst','diamond')) default 'bronze',
  week_start date not null,
  week_end date not null
);
grant select on public.leagues to authenticated;
grant all on public.leagues to service_role;
alter table public.leagues enable row level security;
create policy "leagues_read" on public.leagues for select to authenticated using (true);

create table public.user_leagues (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  league_id uuid references public.leagues(id) on delete cascade,
  weekly_xp int default 0,
  rank int,
  promoted boolean,
  demoted boolean,
  unique(user_id, league_id)
);
grant select, insert, update on public.user_leagues to authenticated;
grant all on public.user_leagues to service_role;
alter table public.user_leagues enable row level security;
create policy "ul_read_all" on public.user_leagues for select to authenticated using (true);
create policy "ul_own_write" on public.user_leagues for insert to authenticated with check (auth.uid() = user_id);
create policy "ul_own_update" on public.user_leagues for update to authenticated using (auth.uid() = user_id);
