
-- Fix 1: Restrict profiles SELECT to own profile only
DROP POLICY IF EXISTS profiles_select_all_auth ON public.profiles;
CREATE POLICY profiles_select_own ON public.profiles
  FOR SELECT TO authenticated
  USING (auth.uid() = id);

-- Fix 2: Remove direct INSERT on xp_transactions and route through SECURITY DEFINER fn
DROP POLICY IF EXISTS xp_own_ins ON public.xp_transactions;
REVOKE INSERT ON public.xp_transactions FROM authenticated, anon;

CREATE OR REPLACE FUNCTION public.award_xp(
  _amount integer,
  _source text,
  _reference_id uuid DEFAULT NULL
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _uid uuid := auth.uid();
BEGIN
  IF _uid IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  IF _amount IS NULL OR _amount <= 0 OR _amount > 500 THEN
    RAISE EXCEPTION 'Invalid XP amount';
  END IF;
  IF _source IS NULL OR length(_source) = 0 OR length(_source) > 64 THEN
    RAISE EXCEPTION 'Invalid XP source';
  END IF;

  INSERT INTO public.xp_transactions (user_id, amount, source, reference_id)
  VALUES (_uid, _amount, _source, _reference_id);
END;
$$;

REVOKE ALL ON FUNCTION public.award_xp(integer, text, uuid) FROM public;
GRANT EXECUTE ON FUNCTION public.award_xp(integer, text, uuid) TO authenticated;
