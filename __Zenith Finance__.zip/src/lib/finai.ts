import { supabase } from "@/integrations/supabase/client";

const LEVEL_THRESHOLDS = [0, 200, 500, 900, 1400, 2000, 2700, 3500, 4500, 5700, 7000, 8500, 10100];

export function levelForXP(xp: number) {
  let lvl = 1;
  for (let i = 0; i < LEVEL_THRESHOLDS.length; i++) {
    if (xp >= LEVEL_THRESHOLDS[i]) lvl = i + 1;
  }
  return lvl;
}
export function xpForNextLevel(xp: number) {
  const lvl = levelForXP(xp);
  const next = LEVEL_THRESHOLDS[lvl] ?? xp;
  const prev = LEVEL_THRESHOLDS[lvl - 1] ?? 0;
  return { current: xp - prev, needed: next - prev, toNext: Math.max(0, next - xp), nextLevel: lvl + 1 };
}

export async function awardXP(userId: string, amount: number, source: string, referenceId?: string) {
  await supabase.rpc("award_xp", { _amount: amount, _source: source, _reference_id: referenceId });
  const { data: p } = await supabase.from("profiles").select("xp").eq("id", userId).maybeSingle();
  const newXp = (p?.xp ?? 0) + amount;
  const newLevel = levelForXP(newXp);
  await supabase.from("profiles").update({ xp: newXp, level: newLevel }).eq("id", userId);

  // also bump current league weekly_xp
  const today = new Date().toISOString().slice(0, 10);
  const { data: league } = await supabase
    .from("leagues")
    .select("id, week_start, week_end")
    .lte("week_start", today)
    .gte("week_end", today)
    .maybeSingle();
  if (league) {
    const { data: ul } = await supabase
      .from("user_leagues")
      .select("id, weekly_xp")
      .eq("user_id", userId)
      .eq("league_id", league.id)
      .maybeSingle();
    if (ul) {
      await supabase.from("user_leagues").update({ weekly_xp: (ul.weekly_xp ?? 0) + amount }).eq("id", ul.id);
    } else {
      await supabase.from("user_leagues").insert({ user_id: userId, league_id: league.id, weekly_xp: amount });
    }
  }
}

export async function advanceStreak(userId: string) {
  const { data: p } = await supabase
    .from("profiles")
    .select("streak_count, streak_last_date, streak_freeze_count")
    .eq("id", userId)
    .maybeSingle();
  if (!p) return;
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const todayStr = today.toISOString().slice(0, 10);
  const last = p.streak_last_date ? new Date(p.streak_last_date) : null;
  if (last) last.setHours(0, 0, 0, 0);
  let streak = p.streak_count ?? 0;
  let freezes = p.streak_freeze_count ?? 0;

  if (!last) {
    streak = 1;
  } else if (last.toISOString().slice(0, 10) === todayStr) {
    return;
  } else {
    const diff = Math.round((today.getTime() - last.getTime()) / 86400000);
    if (diff === 1) streak += 1;
    else if (diff === 2 && freezes > 0) { freezes -= 1; streak += 1; }
    else streak = 1;
  }
  await supabase
    .from("profiles")
    .update({ streak_count: streak, streak_last_date: todayStr, streak_freeze_count: freezes })
    .eq("id", userId);
}

export async function setMasteryAtLeast(userId: string, conceptId: string, level: number) {
  const { data } = await supabase
    .from("user_concept_mastery")
    .select("id, mastery_level")
    .eq("user_id", userId)
    .eq("concept_id", conceptId)
    .maybeSingle();
  if (!data) {
    await supabase.from("user_concept_mastery").insert({ user_id: userId, concept_id: conceptId, mastery_level: level });
  } else if ((data.mastery_level ?? 1) < level) {
    await supabase.from("user_concept_mastery").update({ mastery_level: level }).eq("id", data.id);
  }
}

export async function maybeAwardBadge(userId: string, slug: string) {
  const { data: badge } = await supabase.from("badges").select("id").eq("slug", slug).maybeSingle();
  if (!badge) return;
  await supabase.from("user_badges").insert({ user_id: userId, badge_id: badge.id }).select();
}

export const masteryLabel = (n: number) =>
  ["Aware", "Learning", "Practicing", "Proficient", "Mastered"][Math.max(0, Math.min(4, n - 1))];

export const domainLabel = (d: string) =>
  ({ markets: "Markets", investing: "Investing", macro: "Macro", corporate_finance: "Corporate Finance" } as Record<string, string>)[d] ?? d;
