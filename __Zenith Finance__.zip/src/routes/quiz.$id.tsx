import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { PrimaryButton, SegmentBar, Confetti } from "@/components/ui-bw";
import { advanceStreak, awardXP, maybeAwardBadge, setMasteryAtLeast } from "@/lib/finai";

export const Route = createFileRoute("/quiz/$id")({
  component: QuizPlayer,
});

type Q = { question: string; options: string[]; correct_index: number; explanation: string };

function QuizPlayer() {
  const { id } = Route.useParams();
  const { session } = useAuth();
  const nav = useNavigate();
  const [quiz, setQuiz] = useState<any>(null);
  const [lesson, setLesson] = useState<any>(null);
  const [qIdx, setQIdx] = useState(0);
  const [hearts, setHearts] = useState(3);
  const [answered, setAnswered] = useState<number | null>(null);
  const [answers, setAnswers] = useState<number[]>([]);
  const [score, setScore] = useState<number | null>(null);

  useEffect(() => {
    (async () => {
      const { data: q } = await supabase.from("quizzes").select("*, lessons(concept_id)").eq("id", id).maybeSingle();
      setQuiz(q); setLesson(q?.lessons);
    })();
  }, [id]);

  const questions = useMemo<Q[]>(() => (quiz?.questions ?? []) as Q[], [quiz]);
  const cur = questions[qIdx];

  const choose = (i: number) => {
    if (answered !== null) return;
    setAnswered(i);
    const correct = i === cur.correct_index;
    if (!correct) setHearts(h => Math.max(0, h - 1));
    setAnswers(a => [...a, i]);
  };

  const next = async () => {
    if (qIdx + 1 < questions.length) {
      setQIdx(qIdx + 1); setAnswered(null);
    } else {
      const correctCount = answers.reduce((acc, a, idx) => acc + (a === questions[idx].correct_index ? 1 : 0), 0);
      const s = Math.round((correctCount / questions.length) * 100);
      setScore(s);
      if (session && quiz) {
        const passed = s >= (quiz.pass_threshold ?? 70);
        await supabase.from("user_quiz_results").insert({
          user_id: session.user.id, quiz_id: quiz.id, score: s, passed, answers,
        });
        if (passed) {
          await awardXP(session.user.id, quiz.xp_reward, "quiz", quiz.id);
          if (lesson?.concept_id) await setMasteryAtLeast(session.user.id, lesson.concept_id, 3);
          if (s === 100) await maybeAwardBadge(session.user.id, "quiz-ace");
          await advanceStreak(session.user.id);
        }
      }
    }
  };

  if (!quiz) return <div className="min-h-screen bg-black flex items-center justify-center text-text-muted text-xs uppercase">Loading…</div>;

  if (score !== null) {
    const passed = score >= (quiz.pass_threshold ?? 70);
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center px-6 relative">
        {passed && <Confetti />}
        <p className="text-text-muted text-xs uppercase tracking-wider">Your score</p>
        <p className="text-white text-6xl font-medium mt-3">{score}</p>
        <p className="text-text-secondary mt-2">{passed ? `+${quiz.xp_reward} XP earned` : "Below pass threshold"}</p>
        <div className="mt-10 w-full max-w-sm space-y-3">
          {passed ? (
            <PrimaryButton onClick={() => nav({ to: "/home" })}>Continue →</PrimaryButton>
          ) : (
            <PrimaryButton onClick={() => { setScore(null); setQIdx(0); setAnswered(null); setAnswers([]); setHearts(3); }}>Try again</PrimaryButton>
          )}
          <button onClick={() => nav({ to: "/home" })} className="text-text-secondary text-sm w-full">Back to home</button>
        </div>
      </div>
    );
  }

  if (hearts === 0) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center px-6">
        <p className="text-white text-2xl font-medium">Out of hearts</p>
        <p className="text-text-secondary mt-2">Review the lesson and try again.</p>
        <PrimaryButton className="mt-8 max-w-xs" onClick={() => nav({ to: "/home" })}>Back to home</PrimaryButton>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black flex flex-col">
      <div className="flex items-center gap-3 px-4 pt-4">
        <div className="text-sm tracking-widest">
          {[0,1,2].map(i => (
            <span key={i} className={i < hearts ? "text-white" : "text-text-faint"}>♥</span>
          ))}
        </div>
        <SegmentBar total={questions.length} current={qIdx + 1} />
        <span className="text-[10px] text-text-muted">+{quiz.xp_reward} XP</span>
      </div>

      <div className="flex-1 px-4 py-6">
        <div className="bg-surface-1 border border-border-default rounded-[16px] p-6">
          <p className="text-white text-[15px]">{cur.question}</p>
          <div className="mt-6 space-y-2">
            {cur.options.map((o, i) => {
              const isAnswered = answered !== null;
              const isCorrect = i === cur.correct_index;
              const isSelected = answered === i;
              let cls = "border-border-default";
              if (isAnswered && isSelected && isCorrect) cls = "border-white";
              else if (isAnswered && isSelected && !isCorrect) cls = "border-[#555]";
              else if (isAnswered && isCorrect) cls = "border-white";
              return (
                <button key={i} disabled={isAnswered} onClick={() => choose(i)}
                  className={`w-full text-left bg-surface-2 border ${cls} rounded-[12px] px-4 py-3 text-white flex items-center justify-between`}>
                  <span>{o}</span>
                  {isAnswered && isSelected && (isCorrect ? <span>✓</span> : <span>✗</span>)}
                  {isAnswered && !isSelected && isCorrect && <span>✓</span>}
                </button>
              );
            })}
          </div>
          {answered !== null && (
            <div className="mt-5">
              <p className="text-text-secondary text-sm">{cur.explanation}</p>
              <p className="text-text-muted text-xs mt-2">82% of learners got this right</p>
            </div>
          )}
        </div>
      </div>

      <div className="px-4 pb-6">
        <PrimaryButton onClick={next} disabled={answered === null}>
          {qIdx + 1 < questions.length ? "Next →" : "Finish →"}
        </PrimaryButton>
      </div>
    </div>
  );
}
