import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { PrimaryButton } from "@/components/ui-bw";
import { advanceStreak, awardXP, maybeAwardBadge, setMasteryAtLeast } from "@/lib/finai";

export const Route = createFileRoute("/simulation/$id")({
  component: SimPlayer,
});

function SimPlayer() {
  const { id } = Route.useParams();
  const { session } = useAuth();
  const nav = useNavigate();
  const [sim, setSim] = useState<any>(null);
  const [chosen, setChosen] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);

  useEffect(() => {
    supabase.from("simulations").select("*, concepts(title)").eq("id", id).maybeSingle().then(({ data }) => setSim(data));
  }, [id]);

  const submit = async () => {
    if (chosen === null || !sim || !session) return;
    setSaving(true);
    await supabase.from("user_simulation_results").insert({ user_id: session.user.id, simulation_id: sim.id, choice_index: chosen });
    await awardXP(session.user.id, sim.xp_reward, "simulation", sim.id);
    if (sim.concept_id) await setMasteryAtLeast(session.user.id, sim.concept_id, 4);
    await maybeAwardBadge(session.user.id, "simulation-pro");
    await advanceStreak(session.user.id);
    setDone(true);
  };

  if (!sim) return <div className="min-h-screen bg-black flex items-center justify-center text-text-muted text-xs uppercase">Loading…</div>;

  if (done) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center px-6">
        <p className="text-white text-5xl font-medium">+{sim.xp_reward} XP</p>
        <p className="text-text-secondary mt-3">Simulation complete</p>
        <PrimaryButton className="mt-10 max-w-xs" onClick={() => nav({ to: "/home" })}>Continue →</PrimaryButton>
      </div>
    );
  }

  const choices = (sim.choices ?? []) as { text: string; outcome: string; feedback: string }[];

  return (
    <div className="min-h-screen bg-black flex flex-col px-4 pt-6 pb-8 max-w-2xl mx-auto w-full">
      <button onClick={() => nav({ to: "/home" })} className="text-text-secondary text-sm self-start mb-4">✕</button>
      <p className="text-text-muted text-[10px] uppercase tracking-wider">{sim.concepts?.title}</p>
      <h1 className="text-white text-2xl font-medium mt-1">Simulation</h1>

      <div className="bg-surface-1 border border-border-default rounded-[12px] p-5 mt-6">
        <p className="text-text-muted text-[10px] uppercase tracking-wider">Scenario</p>
        <p className="text-white text-base mt-2 leading-[1.7]">{sim.scenario}</p>
      </div>

      <div className="mt-5 space-y-3">
        {choices.map((c, i) => {
          const sel = chosen === i;
          const fakePct = [42, 31, 27][i] ?? 33;
          return (
            <button key={i} onClick={() => setChosen(i)}
              className={`w-full text-left bg-surface-2 border ${sel ? "border-white" : "border-border-default"} rounded-[12px] p-4`}>
              <p className="text-white">{c.text}</p>
              {sel && (
                <>
                  <p className="text-text-secondary text-sm mt-3">{c.feedback}</p>
                </>
              )}
              <p className="text-text-muted text-xs mt-2">{fakePct}% of learners chose this</p>
            </button>
          );
        })}
      </div>

      <div className="mt-auto pt-6">
        <PrimaryButton disabled={chosen === null || saving} onClick={submit}>
          {saving ? "…" : "Continue →"}
        </PrimaryButton>
      </div>
    </div>
  );
}
