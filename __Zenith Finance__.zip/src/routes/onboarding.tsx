import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { PrimaryButton, SegmentBar } from "@/components/ui-bw";

export const Route = createFileRoute("/onboarding")({
  head: () => ({ meta: [{ title: "Welcome — Find.ai" }] }),
  component: Onboarding,
});

const GOALS = [
  { value: "wealth", icon: "📈", title: "Grow my wealth", sub: "Investing, equity, mutual funds" },
  { value: "markets", icon: "📰", title: "Understand markets", sub: "News, macroeconomics, global trends" },
  { value: "exams", icon: "🎓", title: "Prepare for exams", sub: "CFA, structured curriculum, concepts" },
] as const;

function Onboarding() {
  const { session, profile, refreshProfile, loading } = useAuth();
  const nav = useNavigate();
  const [step, setStep] = useState(2);
  const [goal, setGoal] = useState<"wealth" | "markets" | "exams" | null>(null);
  const [minutes, setMinutes] = useState(5);
  const [name, setName] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (loading) return;
    if (!session) nav({ to: "/auth" });
    else if (profile?.goal) nav({ to: "/home" });
    else if (profile?.display_name) setName(profile.display_name);
  }, [loading, session, profile, nav]);

  const finish = async () => {
    if (!session) return;
    setSaving(true);
    await supabase.from("profiles").update({
      goal, daily_goal_minutes: minutes, display_name: name.trim() || "Learner",
    }).eq("id", session.user.id);
    await refreshProfile();
    nav({ to: "/home" });
  };

  return (
    <div className="min-h-screen bg-black flex flex-col max-w-md mx-auto px-6 py-8">
      <div className="flex items-center gap-3 mb-10">
        <SegmentBar total={4} current={step} />
        <span className="text-xs text-text-muted">{step}/4</span>
      </div>

      {step === 2 && (
        <div className="flex-1 flex flex-col">
          <h2 className="text-2xl font-medium">What's your main goal with money?</h2>
          <p className="text-text-secondary mt-2">We'll build a learning path just for you.</p>
          <div className="mt-8 space-y-3">
            {GOALS.map((g) => {
              const sel = goal === g.value;
              return (
                <button
                  key={g.value}
                  onClick={() => setGoal(g.value)}
                  className={`w-full text-left bg-surface-1 border rounded-[12px] p-4 ${sel ? "border-white" : "border-border-default"}`}
                >
                  <div className="flex items-start gap-3">
                    <span className="text-2xl">{g.icon}</span>
                    <div>
                      <p className={`font-medium ${sel ? "text-white" : "text-white"}`}>{g.title}</p>
                      <p className="text-text-secondary text-sm">{g.sub}</p>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
          <div className="mt-auto pt-6">
            <PrimaryButton onClick={() => setStep(3)} disabled={!goal}>Continue →</PrimaryButton>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="flex-1 flex flex-col">
          <h2 className="text-2xl font-medium">How many minutes per day?</h2>
          <div className="mt-8 grid grid-cols-3 gap-3">
            {[5, 10, 15].map((m) => (
              <button
                key={m}
                onClick={() => setMinutes(m)}
                className={`h-12 rounded-[8px] border bg-surface-1 ${minutes === m ? "border-white text-white" : "border-border-default text-text-secondary"}`}
              >
                {m} min
              </button>
            ))}
          </div>
          <p className="text-text-muted text-sm mt-4">Even 5 minutes a day builds a real habit.</p>
          <div className="mt-auto pt-6">
            <PrimaryButton onClick={() => setStep(4)}>Continue →</PrimaryButton>
          </div>
        </div>
      )}

      {step === 4 && (
        <div className="flex-1 flex flex-col">
          <h2 className="text-2xl font-medium">What should we call you?</h2>
          <input
            value={name} onChange={(e) => setName(e.target.value)}
            placeholder="Your name"
            className="mt-8 w-full h-12 px-4 bg-transparent border border-border-default rounded-[8px] focus:border-white"
          />
          <div className="mt-auto pt-6">
            <PrimaryButton onClick={finish} disabled={saving || !name.trim()}>
              {saving ? "…" : "Build my plan →"}
            </PrimaryButton>
          </div>
        </div>
      )}
    </div>
  );
}
