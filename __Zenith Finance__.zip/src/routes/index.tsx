import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/")({
  component: Landing,
});

function Landing() {
  const { session, profile, loading } = useAuth();
  const nav = useNavigate();
  useEffect(() => {
    if (loading) return;
    if (!session) nav({ to: "/auth" });
    else if (profile && !profile.goal) nav({ to: "/onboarding" });
    else if (profile) nav({ to: "/home" });
  }, [loading, session, profile, nav]);

  return (
    <div className="min-h-screen bg-black flex items-center justify-center">
      <div className="text-text-muted text-xs uppercase tracking-wider">Loading…</div>
    </div>
  );
}
