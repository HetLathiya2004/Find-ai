import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import AppShell, { PageHeader } from "@/components/AppShell";
import { Card } from "@/components/ui-bw";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { domainLabel, masteryLabel } from "@/lib/finai";

export const Route = createFileRoute("/learn/")({
  head: () => ({ meta: [{ title: "Learn — Find.ai" }] }),
  component: LearnPage,
});

const DOMAINS = [
  { v: "all", l: "All" }, { v: "markets", l: "Markets" }, { v: "investing", l: "Investing" },
  { v: "macro", l: "Macro" }, { v: "corporate_finance", l: "Corporate Finance" },
];

function LearnPage() {
  const { session } = useAuth();
  const [domain, setDomain] = useState("all");
  const [concepts, setConcepts] = useState<any[]>([]);
  const [mastery, setMastery] = useState<Record<string, number>>({});

  useEffect(() => {
    supabase.from("concepts").select("*").order("order_index").then(({ data }) => setConcepts(data ?? []));
    if (session) {
      supabase.from("user_concept_mastery").select("concept_id, mastery_level").eq("user_id", session.user.id).then(({ data }) => {
        const m: Record<string, number> = {};
        (data ?? []).forEach((r: any) => m[r.concept_id] = r.mastery_level);
        setMastery(m);
      });
    }
  }, [session]);

  const filtered = domain === "all" ? concepts : concepts.filter(c => c.domain === domain);

  return (
    <AppShell>
      <PageHeader title="Learn" />
      <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4 mb-4">
        {DOMAINS.map(d => (
          <button key={d.v} onClick={() => setDomain(d.v)}
            className={`shrink-0 px-3 h-8 text-xs rounded-[6px] border ${domain === d.v ? "border-white text-white" : "border-border-default text-text-secondary"}`}>
            {d.l}
          </button>
        ))}
      </div>
      <div className="space-y-3">
        {filtered.map(c => {
          const lvl = mastery[c.id] ?? 1;
          return (
            <Link key={c.id} to="/learn/$slug" params={{ slug: c.slug }} className="block">
              <Card>
                <div className="flex items-start justify-between mb-2">
                  <p className="text-white font-medium">{c.title}</p>
                  <span className="text-[10px] uppercase text-text-muted">{domainLabel(c.domain)}</span>
                </div>
                <div className="h-1.5 bg-border-default rounded-full overflow-hidden">
                  <div className="h-full bg-white" style={{ width: `${(lvl / 5) * 100}%` }} />
                </div>
                <p className="text-text-muted text-xs mt-2">Level {lvl} · {masteryLabel(lvl)}</p>
              </Card>
            </Link>
          );
        })}
        {filtered.length === 0 && (
          <p className="text-text-muted text-sm text-center py-12">No concepts in this domain yet.</p>
        )}
      </div>
    </AppShell>
  );
}
