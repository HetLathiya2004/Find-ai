import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import AppShell from "@/components/AppShell";
import { Card, Tag, PrimaryButton, ProgressBar } from "@/components/ui-bw";

export const Route = createFileRoute("/home")({
  head: () => ({ meta: [{ title: "Home — Find.ai" }] }),
  component: HomePage,
});

function HomePage() {
  const { profile, session } = useAuth();
  const [resume, setResume] = useState<any>(null);
  const [news, setNews] = useState<any>(null);
  const [challenge, setChallenge] = useState<any>(null);
  const [doneToday, setDoneToday] = useState(0);
  const [league, setLeague] = useState<any>(null);
  const [rank, setRank] = useState<number | null>(null);

  useEffect(() => {
    if (!session) return;
    (async () => {
      const today = new Date().toISOString().slice(0, 10);
      const [{ data: rp }, { data: n }, { data: dc }] = await Promise.all([
        supabase.from("user_lesson_progress").select("*, lessons(title, slug, cards)").eq("user_id", session.user.id).eq("status", "in_progress").limit(1).maybeSingle(),
        supabase.from("news_articles").select("*, concepts(title, slug)").order("published_at", { ascending: false }).limit(1).maybeSingle(),
        supabase.from("daily_challenges").select("*, lessons(title, slug)").eq("challenge_date", today).maybeSingle(),
      ]);
      setResume(rp); setNews(n); setChallenge(dc);

      const startOfDay = new Date(); startOfDay.setHours(0,0,0,0);
      const { count } = await supabase
        .from("xp_transactions")
        .select("id", { count: "exact", head: true })
        .eq("user_id", session.user.id)
        .gte("created_at", startOfDay.toISOString());
      setDoneToday(count ?? 0);

      const { data: lg } = await supabase
        .from("leagues").select("*").lte("week_start", today).gte("week_end", today).maybeSingle();
      if (lg) {
        setLeague(lg);
        const { data: ranks } = await supabase
          .from("user_leagues").select("user_id, weekly_xp").eq("league_id", lg.id).order("weekly_xp", { ascending: false });
        if (ranks) {
          const idx = ranks.findIndex((r: any) => r.user_id === session.user.id);
          setRank(idx >= 0 ? idx + 1 : ranks.length + 1);
        }
      }
    })();
  }, [session]);

  const [greeting, setGreeting] = useState("Hello");
  useEffect(() => {
    const h = new Date().getHours();
    setGreeting(h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening");
  }, []);
  const goalTotal = 5;
  const pct = Math.min(100, Math.round((doneToday / goalTotal) * 100));
  const ringSize = 88;
  const ringStroke = 6;
  const ringR = (ringSize - ringStroke) / 2;
  const ringC = 2 * Math.PI * ringR;
  const ringOffset = ringC * (1 - pct / 100);

  return (
    <AppShell>
      <div className="flex items-center justify-between mb-6">
        <div>
          <p className="text-text-secondary text-sm">{greeting},</p>
          <p className="text-white font-medium">{profile?.display_name ?? "Learner"}</p>
        </div>
        <div className="flex items-center gap-2">
          <Link to="/streak" className="px-3 h-9 inline-flex items-center gap-1.5 text-sm bg-surface-1 border border-border-strong rounded-[8px]">
            🔥 <span className="font-medium">{profile?.streak_count ?? 0}</span>
          </Link>
          <div className="px-3 h-9 inline-flex items-center gap-1.5 text-sm bg-surface-1 border border-border-strong rounded-[8px]">
            ⚡ <span className="font-medium">{profile?.xp ?? 0}</span> <span className="text-text-muted">XP</span>
          </div>
        </div>
      </div>

      <Card className="flex items-center gap-5">
        <svg width={ringSize} height={ringSize} className="-rotate-90 shrink-0">
          <circle cx={ringSize/2} cy={ringSize/2} r={ringR} stroke="#1F1F1F" strokeWidth={ringStroke} fill="none" />
          <circle cx={ringSize/2} cy={ringSize/2} r={ringR} stroke="#fff" strokeWidth={ringStroke} fill="none"
            strokeDasharray={ringC} strokeDashoffset={ringOffset} strokeLinecap="round" />
          <text x="50%" y="50%" textAnchor="middle" dominantBaseline="middle" className="rotate-90" transform={`rotate(90 ${ringSize/2} ${ringSize/2})`} fill="#fff" fontSize="18" fontWeight="500">{pct}%</text>
        </svg>
        <div className="flex-1">
          <p className="text-white font-medium">Daily goal</p>
          <p className="text-text-secondary text-sm">{Math.min(doneToday, goalTotal)} of {goalTotal} done</p>
          {doneToday < goalTotal && (
            <p className="text-white text-xs mt-1">{goalTotal - doneToday} left → bonus XP on finish</p>
          )}
        </div>
      </Card>

      {resume && (
        <div className="mt-4">
          <Card border="white">
            <Tag>RESUME WHERE YOU LEFT OFF</Tag>
            <p className="text-white font-medium mt-2">{resume.lessons?.title}</p>
            <div className="mt-3">
              <ProgressBar value={resume.card_index} max={resume.lessons?.cards?.length ?? 5} />
            </div>
            <p className="text-text-muted text-xs mt-2">
              {Math.round(((resume.card_index ?? 0) / (resume.lessons?.cards?.length ?? 5)) * 100)}% complete · +20 XP on finish
            </p>
            <Link to="/lesson/$slug" params={{ slug: resume.lessons.slug }}>
              <PrimaryButton className="mt-4">Continue →</PrimaryButton>
            </Link>
          </Card>
        </div>
      )}

      {news && (
        <div className="mt-4">
          <Card>
            <Tag>FROM TODAY'S NEWS</Tag>
            <p className="text-white font-medium mt-2">{news.title}</p>
            <p className="text-text-secondary text-sm mt-1">
              Learn what {news.concepts?.title ?? "this"} means → +10 bonus XP
            </p>
            <Link to="/news" className="inline-block mt-3 text-xs text-white underline underline-offset-2">Open news →</Link>
          </Card>
        </div>
      )}

      <div className="mt-4">
        <Card>
          <p className="text-text-secondary text-sm capitalize">{league?.tier ?? "Bronze"} League</p>
          <div className="flex items-end justify-between mt-2">
            <p className="text-white text-3xl font-medium">#{rank ?? "—"}</p>
            <p className="text-text-secondary text-sm">of 30</p>
          </div>
          <p className="text-text-muted text-xs mt-2">Resets Sunday</p>
          <Link to="/league" className="inline-block mt-3 text-xs text-white underline underline-offset-2">View leaderboard →</Link>
        </Card>
      </div>

      {challenge && (
        <div className="mt-4">
          <Card>
            <Tag>DAILY CHALLENGE</Tag>
            <p className="text-white font-medium mt-2">{challenge.lessons?.title}</p>
            <p className="text-text-secondary text-sm">+{challenge.xp_reward} XP reward</p>
            <Link to="/lesson/$slug" params={{ slug: challenge.lessons?.slug }}>
              <PrimaryButton className="mt-4">Start challenge →</PrimaryButton>
            </Link>
          </Card>
        </div>
      )}
    </AppShell>
  );
}
