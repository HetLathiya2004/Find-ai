import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { PrimaryButton, GhostButton } from "@/components/ui-bw";

export const Route = createFileRoute("/auth")({
  head: () => ({ meta: [{ title: "Sign in — Find.ai" }] }),
  component: AuthPage,
});

function AuthPage() {
  const [mode, setMode] = useState<"signup" | "signin">("signup");
  const [view, setView] = useState<"welcome" | "form">("welcome");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const { session, profile } = useAuth();
  const nav = useNavigate();

  useEffect(() => {
    if (session) nav({ to: profile?.goal ? "/home" : "/onboarding" });
  }, [session, profile, nav]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null); setLoading(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email, password,
          options: { emailRedirectTo: window.location.origin },
        });
        if (error) throw error;
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
    } catch (e: any) { setError(e.message); } finally { setLoading(false); }
  };

  if (view === "welcome") {
    return (
      <div className="min-h-screen bg-black flex flex-col px-6 py-12 max-w-md mx-auto">
        <div className="flex-1 flex flex-col justify-center">
          <p className="text-text-muted text-xs uppercase tracking-[0.2em] mb-6">Find.ai</p>
          <h1 className="text-4xl md:text-5xl font-medium leading-tight">
            Learn finance.<br />In 5 minutes a day.
          </h1>
          <p className="text-text-secondary mt-4 text-base">
            Duolingo-style lessons for markets, investing, and economics.
          </p>
        </div>
        <div className="space-y-3">
          <PrimaryButton onClick={() => { setMode("signup"); setView("form"); }}>Get started</PrimaryButton>
          <GhostButton onClick={() => { setMode("signin"); setView("form"); }}>I already have an account</GhostButton>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black flex flex-col px-6 py-12 max-w-md mx-auto">
      <button onClick={() => setView("welcome")} className="text-text-secondary text-sm self-start mb-8">← back</button>
      <h2 className="text-2xl font-medium">{mode === "signup" ? "Create your account" : "Welcome back"}</h2>
      <p className="text-text-muted text-sm mt-1">{mode === "signup" ? "Start learning in 30 seconds." : "Sign in to continue."}</p>
      <form onSubmit={submit} className="mt-8 space-y-4">
        <div>
          <label className="text-xs uppercase tracking-wider text-text-muted">Email</label>
          <input
            type="email" required value={email} onChange={(e) => setEmail(e.target.value)}
            className="w-full mt-2 h-11 px-4 bg-transparent border border-border-default rounded-[8px] focus:border-white"
          />
        </div>
        <div>
          <label className="text-xs uppercase tracking-wider text-text-muted">Password</label>
          <input
            type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)}
            className="w-full mt-2 h-11 px-4 bg-transparent border border-border-default rounded-[8px] focus:border-white"
          />
        </div>
        {error && <p className="text-sm" style={{ color: "#999" }}>{error}</p>}
        <PrimaryButton type="submit" disabled={loading}>
          {loading ? "…" : mode === "signup" ? "Create account" : "Sign in"}
        </PrimaryButton>
        <button
          type="button" onClick={() => setMode(mode === "signup" ? "signin" : "signup")}
          className="text-text-secondary text-sm w-full text-center"
        >
          {mode === "signup" ? "Have an account? Sign in" : "Need an account? Sign up"}
        </button>
      </form>
    </div>
  );
}
