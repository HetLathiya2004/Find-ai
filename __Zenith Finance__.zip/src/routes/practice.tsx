import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import AppShell, { PageHeader } from "@/components/AppShell";
import { Card } from "@/components/ui-bw";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { masteryLabel } from "@/lib/finai";

export const Route = createFileRoute("/practice")({
  head: () => ({ meta: [{ title: "Practice — Find.ai" }] }),
  component: PracticePage,
});

function PracticePage() {
  const { session } = useAuth();
  const nav = useNavigate();
  const [due, setDue] = useState<any[]>([]);
  const [weak, setWeak] = useState<any[]>([]);
  const [sims, setSims] = useState<any[]>([]);

  useEffect(() => {
    if (!session) return;
    const today = new Date().toISOString().slice(0,10);
    (async () => {
      const { data: m } = await supabase.from("user_concept_mastery").select("*, concepts(title, slug)").eq("user_id", session.user.id);
      setDue((m ?? []).filter((x: any) => x.next_review_date && x.next_review_date <= today));
      setWeak((m ?? []).filter((x: any) => (x.mastery_level ?? 1) <= 2));
      const { data: s } = await supabase.from("simulations").select("*, concepts(title, slug)").limit(10);
      setSims(s ?? []);
    })();
  }, [session]);

  const Row = ({ title, sub, action }: { title: string; sub: string; action: () => void }) => (
    <button onClick={action} className="w-full flex items-center justify-between py-3 border-b border-border-default text-left">
      <div>
        <p className="text-white">{title}</p>
        <p className="text-text-muted text-xs mt-0.5">{sub}</p>
      </div>
      <span className="text-xs text-white">→</span>
    </button>
  );

  return (
    <AppShell>
      <PageHeader title="Practice" />

      <p className="text-text-muted text-[10px] uppercase tracking-wider mb-2">Due for review</p>
      <Card className="!p-2 mb-6">
        <div className="px-3">
          {due.length === 0 && <p className="text-text-muted text-sm py-4">Nothing due yet. Keep learning.</p>}
          {due.map(d => (
            <Row key={d.id} title={d.concepts.title} sub="Review · +15 XP"
              action={() => nav({ to: "/learn/$slug", params: { slug: d.concepts.slug } })} />
          ))}
        </div>
      </Card>

      <p className="text-text-muted text-[10px] uppercase tracking-wider mb-2">Weak concepts</p>
      <Card className="!p-2 mb-6">
        <div className="px-3">
          {weak.length === 0 && <p className="text-text-muted text-sm py-4">No weak concepts. Strong work.</p>}
          {weak.map(w => (
            <Row key={w.id} title={w.concepts.title} sub={`${masteryLabel(w.mastery_level ?? 1)} · Practice`}
              action={() => nav({ to: "/learn/$slug", params: { slug: w.concepts.slug } })} />
          ))}
        </div>
      </Card>

      <p className="text-text-muted text-[10px] uppercase tracking-wider mb-2">Simulations</p>
      <Card className="!p-2">
        <div className="px-3">
          {sims.map(s => (
            <Row key={s.id} title={s.title} sub={`${s.concepts?.title ?? "—"} · +${s.xp_reward} XP`}
              action={() => nav({ to: "/simulation/$id", params: { id: s.id } })} />
          ))}
        </div>
      </Card>
    </AppShell>
  );
}
