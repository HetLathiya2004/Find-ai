import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import AppShell from "@/components/AppShell";
import { Card } from "@/components/ui-bw";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { masteryLabel } from "@/lib/finai";

export const Route = createFileRoute("/learn/$slug")({
  component: ConceptDetail,
});

function ConceptDetail() {
  const { slug } = Route.useParams();
  const { session } = useAuth();
  const nav = useNavigate();
  const [concept, setConcept] = useState<any>(null);
  const [lesson, setLesson] = useState<any>(null);
  const [quiz, setQuiz] = useState<any>(null);
  const [sim, setSim] = useState<any>(null);
  const [lp, setLp] = useState<any>(null);
  const [qr, setQr] = useState<any>(null);
  const [sr, setSr] = useState<any>(null);
  const [mastery, setMastery] = useState(1);

  useEffect(() => {
    (async () => {
      const { data: c } = await supabase.from("concepts").select("*").eq("slug", slug).maybeSingle();
      if (!c) return;
      setConcept(c);
      const { data: l } = await supabase.from("lessons").select("*").eq("concept_id", c.id).order("order_index").limit(1).maybeSingle();
      setLesson(l);
      if (l) {
        const { data: q } = await supabase.from("quizzes").select("*").eq("lesson_id", l.id).maybeSingle();
        setQuiz(q);
      }
      const { data: s } = await supabase.from("simulations").select("*").eq("concept_id", c.id).limit(1).maybeSingle();
      setSim(s);
      if (session) {
        if (l) {
          const { data: p } = await supabase.from("user_lesson_progress").select("*").eq("user_id", session.user.id).eq("lesson_id", l.id).maybeSingle();
          setLp(p);
        }
        const { data: m } = await supabase.from("user_concept_mastery").select("mastery_level").eq("user_id", session.user.id).eq("concept_id", c.id).maybeSingle();
        if (m) setMastery(m.mastery_level ?? 1);
      }
    })();
  }, [slug, session]);

  useEffect(() => {
    if (!quiz || !session) return;
    supabase.from("user_quiz_results").select("*").eq("user_id", session.user.id).eq("quiz_id", quiz.id).order("completed_at", { ascending: false }).limit(1).maybeSingle().then(({ data }) => setQr(data));
  }, [quiz, session]);
  useEffect(() => {
    if (!sim || !session) return;
    supabase.from("user_simulation_results").select("*").eq("user_id", session.user.id).eq("simulation_id", sim.id).limit(1).maybeSingle().then(({ data }) => setSr(data));
  }, [sim, session]);

  if (!concept) return <AppShell><div className="skeleton h-32" /></AppShell>;

  const lessonDone = lp?.status === "completed" || lp?.status === "mastered";
  const quizPassed = qr?.passed;
  const simDone = !!sr;

  const StatusChip = ({ children }: { children: string }) => (
    <span className="text-[11px] px-2 py-0.5 rounded-[6px] border border-border-strong text-text-secondary">{children}</span>
  );

  const Row = ({ title, xp, status, locked, onTap }: { title: string; xp: number; status: string; locked?: boolean; onTap?: () => void }) => (
    <button disabled={locked} onClick={onTap}
      className={`w-full text-left flex items-center justify-between py-4 border-b border-border-default ${locked ? "opacity-40" : ""}`}>
      <div>
        <p className="text-white font-medium">{title}</p>
        <p className="text-text-muted text-xs mt-0.5">+{xp} XP {locked ? "· locked" : ""}</p>
      </div>
      <StatusChip>{status}</StatusChip>
    </button>
  );

  return (
    <AppShell>
      <button onClick={() => nav({ to: "/learn" })} className="text-text-secondary text-sm mb-4">← Back</button>
      <h1 className="text-2xl font-medium text-white">{concept.title}</h1>
      <p className="text-text-secondary mt-2">{concept.description}</p>

      <Card className="mt-6 !p-2">
        <div className="px-3">
          {lesson && (
            <Row title="Lesson" xp={lesson.xp_reward}
              status={lessonDone ? "Complete" : lp?.status === "in_progress" ? "In Progress" : "Start"}
              onTap={() => nav({ to: "/lesson/$slug", params: { slug: lesson.slug } })} />
          )}
          {quiz && (
            <Row title="Quiz" xp={quiz.xp_reward}
              status={quizPassed ? `Passed · ${qr.score}%` : "Start"}
              locked={!lessonDone}
              onTap={() => nav({ to: "/quiz/$id", params: { id: quiz.id } })} />
          )}
          {sim && (
            <Row title="Simulation" xp={sim.xp_reward}
              status={simDone ? "Complete" : "Start"}
              locked={!quizPassed}
              onTap={() => nav({ to: "/simulation/$id", params: { id: sim.id } })} />
          )}
        </div>
      </Card>

      <div className="mt-6">
        <p className="text-text-muted text-xs uppercase tracking-wider mb-2">Mastery</p>
        <div className="flex items-center gap-2">
          {[1,2,3,4,5].map(n => (
            <div key={n} className={`w-3 h-3 rounded-full ${n <= mastery ? "bg-white" : "bg-border-default"}`} />
          ))}
          <span className="text-text-secondary text-sm ml-2">{masteryLabel(mastery)}</span>
        </div>
      </div>
    </AppShell>
  );
}
