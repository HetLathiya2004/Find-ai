import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import AppShell from "@/components/AppShell";
import { Card } from "@/components/ui-bw";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { levelForXP, masteryLabel, xpForNextLevel } from "@/lib/finai";

export const Route = createFileRoute("/profile")({
  head: () => ({ meta: [{ title: "Profile — Find.ai" }] }),
  component: ProfilePage,
});

const GOAL_LABEL: Record<string, string> = {
  wealth: "Growing my wealth", markets: "Understanding markets", exams: "Preparing for exams",
};

function ProfilePage() {
  const { profile, session, signOut, refreshProfile } = useAuth();
  const nav = useNavigate();
  const [badges, setBadges] = useState<any[]>([]);
  const [earned, setEarned] = useState<Set<string>>(new Set());
  const [mastery, setMastery] = useState<any[]>([]);
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(profile?.display_name ?? "");

  useEffect(() => { if (profile?.display_name) setName(profile.display_name); }, [profile?.display_name]);

  useEffect(() => {
    if (!session) return;
    (async () => {
      const { data: b } = await supabase.from("badges").select("*");
      setBadges(b ?? []);
      const { data: ub } = await supabase.from("user_badges").select("badge_id").eq("user_id", session.user.id);
      setEarned(new Set((ub ?? []).map((x: any) => x.badge_id)));
      const { data: m } = await supabase.from("user_concept_mastery").select("*, concepts(title)").eq("user_id", session.user.id);
      setMastery(m ?? []);
    })();
  }, [session]);

  const xp = profile?.xp ?? 0;
  const lvl = levelForXP(xp);
  const lvlInfo = xpForNextLevel(xp);
  const init = (profile?.display_name ?? "L").slice(0, 1).toUpperCase();

  return (
    <AppShell>
      <div className="flex items-center gap-4 mb-6">
        <div className="w-16 h-16 rounded-full bg-white text-black flex items-center justify-center text-2xl font-medium">{init}</div>
        <div>
          <p className="text-white text-xl font-medium">{profile?.display_name}</p>
          <p className="text-text-muted text-sm">{profile?.goal ? GOAL_LABEL[profile.goal] : ""}</p>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3 mb-6">
        {[
          { l: "XP", v: xp },
          { l: "Level", v: lvl },
          { l: "Streak", v: profile?.streak_count ?? 0 },
        ].map(s => (
          <Card key={s.l} className="!p-4 text-center">
            <p className="text-white text-2xl font-medium">{s.v}</p>
            <p className="text-text-muted text-[10px] uppercase tracking-wider mt-1">{s.l}</p>
          </Card>
        ))}
      </div>

      <Card className="mb-6">
        <p className="text-white font-medium">Level {lvl}</p>
        <div className="mt-3 h-1.5 bg-border-default rounded-full overflow-hidden">
          <div className="h-full bg-white" style={{ width: `${(lvlInfo.current / lvlInfo.needed) * 100}%` }} />
        </div>
        <p className="text-text-muted text-xs mt-2">{lvlInfo.toNext} XP to Level {lvlInfo.nextLevel}</p>
      </Card>

      <p className="text-text-muted text-[10px] uppercase tracking-wider mb-3">Badges</p>
      <div className="grid grid-cols-3 gap-3 mb-6">
        {badges.map(b => {
          const has = earned.has(b.id);
          return (
            <div key={b.id} className={`p-4 rounded-[12px] border text-center ${has ? "bg-surface-1 border-white" : "bg-surface-1 border-border-default"}`}>
              <p className={`text-2xl ${has ? "" : "opacity-30"}`}>{b.icon}</p>
              <p className={`text-xs mt-2 ${has ? "text-white" : "text-text-faint"}`}>{b.name}</p>
            </div>
          );
        })}
      </div>

      <p className="text-text-muted text-[10px] uppercase tracking-wider mb-2">Mastery</p>
      <Card className="!p-2 mb-6">
        <div className="px-3">
          {mastery.length === 0 && <p className="text-text-muted text-sm py-4">No mastery progress yet.</p>}
          {mastery.map((m: any) => (
            <div key={m.id} className="flex items-center justify-between py-3 border-b border-border-default">
              <div>
                <p className="text-white">{m.concepts?.title}</p>
                <p className="text-text-muted text-xs mt-0.5">{masteryLabel(m.mastery_level ?? 1)}</p>
              </div>
              <div className="flex gap-1">
                {[1,2,3,4,5].map(n => (
                  <div key={n} className={`w-2 h-2 rounded-full ${n <= (m.mastery_level ?? 1) ? "bg-white" : "bg-border-default"}`} />
                ))}
              </div>
            </div>
          ))}
        </div>
      </Card>

      <p className="text-text-muted text-[10px] uppercase tracking-wider mb-2">Settings</p>
      <Card className="!p-2 mb-6">
        <div className="px-3">
          {editing ? (
            <div className="py-3">
              <input value={name} onChange={(e) => setName(e.target.value)}
                className="w-full h-10 px-3 bg-transparent border border-border-default rounded-[8px] focus:border-white" />
              <div className="flex gap-2 mt-3">
                <button
                  onClick={async () => {
                    if (!session) return;
                    await supabase.from("profiles").update({ display_name: name.trim() }).eq("id", session.user.id);
                    await refreshProfile(); setEditing(false);
                  }}
                  className="h-9 px-3 bg-white text-black rounded-[8px] text-sm font-medium">Save</button>
                <button onClick={() => setEditing(false)} className="h-9 px-3 border border-border-default rounded-[8px] text-sm text-text-secondary">Cancel</button>
              </div>
            </div>
          ) : (
            <button onClick={() => setEditing(true)} className="w-full text-left py-3 border-b border-border-default flex justify-between">
              <span className="text-white">Display name</span>
              <span className="text-text-secondary text-sm">{profile?.display_name}</span>
            </button>
          )}
          <button
            onClick={async () => {
              if (!session) return;
              const next = profile?.daily_goal_minutes === 5 ? 10 : profile?.daily_goal_minutes === 10 ? 15 : 5;
              await supabase.from("profiles").update({ daily_goal_minutes: next }).eq("id", session.user.id);
              refreshProfile();
            }}
            className="w-full text-left py-3 border-b border-border-default flex justify-between">
            <span className="text-white">Daily goal</span>
            <span className="text-text-secondary text-sm">{profile?.daily_goal_minutes} min</span>
          </button>
          <button onClick={async () => { await signOut(); nav({ to: "/auth" }); }}
            className="w-full text-left py-3 text-text-secondary">Sign out</button>
        </div>
      </Card>
    </AppShell>
  );
}
