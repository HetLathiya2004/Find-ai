import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  createRootRouteWithContext,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import type { ReactNode } from "react";

import appCss from "../styles.css?url";
import { AuthProvider } from "@/lib/auth";

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { title: "Find.ai — Learn finance in 5 minutes a day" },
      { name: "description", content: "Duolingo-style lessons for markets, investing, and economics." },
      { name: "theme-color", content: "#000000" },
      { property: "og:title", content: "Find.ai — Learn finance in 5 minutes a day" },
      { name: "twitter:title", content: "Find.ai — Learn finance in 5 minutes a day" },
      { property: "og:description", content: "Duolingo-style lessons for markets, investing, and economics." },
      { name: "twitter:description", content: "Duolingo-style lessons for markets, investing, and economics." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/be184d2a-ec9a-44f9-89d2-9a9375052fae/id-preview-af82517c--387e44c8-f24a-4781-b4c7-c394df21c8e3.lovable.app-1782734070388.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/be184d2a-ec9a-44f9-89d2-9a9375052fae/id-preview-af82517c--387e44c8-f24a-4781-b4c7-c394df21c8e3.lovable.app-1782734070388.png" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:type", content: "website" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500&display=swap" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: () => (
    <div className="min-h-screen bg-black text-white flex items-center justify-center px-4">
      <div className="text-center">
        <p className="text-text-muted text-xs uppercase tracking-wider">404</p>
        <h1 className="text-2xl mt-2">Page not found</h1>
        <a href="/" className="inline-block mt-6 bg-white text-black px-5 h-11 leading-[44px] rounded-[8px] font-medium">Go home</a>
      </div>
    </div>
  ),
  errorComponent: ({ error }) => (
    <div className="min-h-screen bg-black text-white flex items-center justify-center px-4">
      <div className="text-center max-w-sm">
        <h1 className="text-xl">Something went wrong</h1>
        <p className="text-text-secondary text-sm mt-2">{error.message}</p>
        <a href="/" className="inline-block mt-6 bg-white text-black px-5 h-11 leading-[44px] rounded-[8px] font-medium">Go home</a>
      </div>
    </div>
  ),
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="bg-black">
      <head>
        <HeadContent />
      </head>
      <body className="bg-black text-white">
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Outlet />
      </AuthProvider>
    </QueryClientProvider>
  );
}
