import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui-bw";

export const Route = createFileRoute("/league")({
  head: () => ({ meta: [{ title: "League — Find.ai" }] }),
  component: LeaguePage,
});

function LeaguePage() {
  const { session } = useAuth();
  const nav = useNavigate();
  const [league, setLeague] = useState<any>(null);
  const [rows, setRows] = useState<any[]>([]);

  useEffect(() => {
    if (!session) return;
    const today = new Date().toISOString().slice(0,10);
    (async () => {
      const { data: lg } = await supabase.from("leagues").select("*").lte("week_start", today).gte("week_end", today).maybeSingle();
      if (!lg) return;
      setLeague(lg);
      const { data: ul } = await supabase.from("user_leagues").select("*, profiles(display_name)").eq("league_id", lg.id).order("weekly_xp", { ascending: false }).limit(30);
      let list: any[] = ul ?? [];
      if (!list.find((r: any) => r.user_id === session.user.id)) {
        const { data: me } = await supabase.from("profiles").select("display_name").eq("id", session.user.id).maybeSingle();
        list = [...list, { user_id: session.user.id, weekly_xp: 0, profiles: { display_name: me?.display_name ?? "You" } }];
      }
      setRows(list);
    })();
  }, [session]);

  const endsIn = league ? Math.max(0, Math.ceil((new Date(league.week_end).getTime() + 86400000 - Date.now()) / 86400000)) : 0;

  return (
    <div className="min-h-screen bg-black flex flex-col px-4 pt-6 pb-12 max-w-2xl mx-auto w-full">
      <button onClick={() => nav({ to: "/home" })} className="text-text-secondary text-sm self-start mb-4">← back</button>

      <div className="flex items-end justify-between mb-6">
        <div>
          <p className="text-white text-2xl font-medium capitalize">🏆 {league?.tier ?? "Bronze"} League</p>
          <p className="text-text-muted text-xs mt-1">Resets in {endsIn}d</p>
        </div>
      </div>

      <p className="text-white text-[10px] uppercase tracking-wider mb-2">↑ Promotion Zone — Top 5</p>
      <Card className="!p-2">
        <div className="px-2">
          {rows.map((r, i) => {
            const me = r.user_id === session?.user.id;
            const promo = i < 5;
            const demo = i >= 25;
            return (
              <div key={r.user_id ?? i}
                className={`flex items-center justify-between py-3 px-3 rounded-[8px] ${me ? "bg-surface-2 border border-white" : "border border-transparent"}`}>
                <div className="flex items-center gap-3">
                  <span className={`w-1.5 h-1.5 rounded-full ${promo ? "bg-white" : demo ? "bg-text-muted" : "bg-transparent"}`} />
                  <span className="text-text-muted text-sm w-6">{i+1}</span>
                  <span className={`${me ? "text-white" : "text-text-secondary"}`}>{r.profiles?.display_name ?? "Learner"}</span>
                </div>
                <span className="text-white text-sm">{r.weekly_xp ?? 0} XP</span>
              </div>
            );
          })}
          {rows.length === 0 && <p className="text-text-muted text-sm py-8 text-center">No league data yet.</p>}
        </div>
      </Card>

      <p className="text-text-muted text-[10px] uppercase tracking-wider mt-4">↓ Demotion Zone — Bottom 5</p>
    </div>
  );
}
