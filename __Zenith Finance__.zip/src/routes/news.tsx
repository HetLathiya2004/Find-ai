import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import AppShell, { PageHeader } from "@/components/AppShell";
import { Card, Chip } from "@/components/ui-bw";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/news")({
  head: () => ({ meta: [{ title: "News — Find.ai" }] }),
  component: NewsPage,
});

function NewsPage() {
  const [arts, setArts] = useState<any[]>([]);
  const nav = useNavigate();

  useEffect(() => {
    supabase.from("news_articles").select("*, concepts(title, slug)").order("published_at", { ascending: false })
      .then(({ data }) => setArts(data ?? []));
  }, []);

  return (
    <AppShell>
      <PageHeader title="News" />
      <div className="space-y-4">
        {arts.map(a => (
          <Card key={a.id}>
            <p className="text-text-muted text-[10px] uppercase tracking-wider">
              {new Date(a.published_at).toLocaleDateString()}
            </p>
            <p className="text-white font-medium mt-2">{a.title}</p>
            <p className="text-text-secondary text-sm mt-2 leading-[1.6]">{a.summary}</p>
            {a.why_it_matters && (
              <div className="mt-3 pt-3 border-t border-border-default">
                <p className="text-text-muted text-[10px] uppercase tracking-wider">Why it matters</p>
                <p className="text-text-secondary text-sm mt-1.5 leading-[1.6]">{a.why_it_matters}</p>
              </div>
            )}
            {a.concepts && (
              <div className="mt-4 flex items-center justify-between gap-3">
                <Chip>{a.concepts.title}</Chip>
                <button
                  onClick={() => nav({ to: "/learn/$slug", params: { slug: a.concepts.slug } })}
                  className="text-xs border border-white rounded-[8px] px-3 h-9 text-white">
                  Learn this concept → +10 XP
                </button>
              </div>
            )}
          </Card>
        ))}
        {arts.length === 0 && <p className="text-text-muted text-sm text-center py-12">No news yet.</p>}
      </div>
    </AppShell>
  );
}
