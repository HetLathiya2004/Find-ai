import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui-bw";

export const Route = createFileRoute("/streak")({
  head: () => ({ meta: [{ title: "Streak — Find.ai" }] }),
  component: StreakPage,
});

function StreakPage() {
  const { profile, session } = useAuth();
  const nav = useNavigate();
  const [activeDates, setActiveDates] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (!session) return;
    const start = new Date(); start.setDate(start.getDate() - 27); start.setHours(0,0,0,0);
    supabase.from("xp_transactions").select("created_at").eq("user_id", session.user.id).gte("created_at", start.toISOString())
      .then(({ data }) => {
        const s = new Set<string>();
        (data ?? []).forEach((r: any) => s.add(new Date(r.created_at).toISOString().slice(0, 10)));
        setActiveDates(s);
      });
  }, [session]);

  const today = new Date(); today.setHours(0,0,0,0);
  const days = Array.from({ length: 28 }).map((_, i) => {
    const d = new Date(today); d.setDate(today.getDate() - (27 - i));
    return d;
  });
  const todayStr = today.toISOString().slice(0, 10);

  return (
    <div className="min-h-screen bg-black flex flex-col px-4 pt-6 pb-12 max-w-2xl mx-auto w-full">
      <button onClick={() => nav({ to: "/home" })} className="text-text-secondary text-sm self-start mb-6">✕</button>

      <div className="text-center mb-8">
        <p className="text-6xl">🔥</p>
        <p className="text-white text-5xl font-medium mt-3">{profile?.streak_count ?? 0}</p>
        <p className="text-text-muted text-sm mt-1">day streak</p>
      </div>

      <Card className="mb-4">
        <p className="text-text-muted text-[10px] uppercase tracking-wider mb-3">Last 28 days</p>
        <div className="grid grid-cols-7 gap-2">
          {days.map((d, i) => {
            const ds = d.toISOString().slice(0, 10);
            const isToday = ds === todayStr;
            const active = activeDates.has(ds);
            return (
              <div key={i} className={`aspect-square rounded-[3px] ${active ? "bg-white" : "bg-border-default"} ${isToday ? "ring-1 ring-white" : ""}`} />
            );
          })}
        </div>
        <p className="text-text-muted text-[10px] mt-4">■ Done   ⬚ Today   □ Upcoming</p>
      </Card>

      <div className="grid grid-cols-2 gap-3 mb-4">
        <Card className="!p-4 text-center">
          <p className="text-text-muted text-[10px] uppercase tracking-wider">Best streak</p>
          <p className="text-white text-2xl font-medium mt-2">{profile?.streak_count ?? 0}</p>
        </Card>
        <Card className="!p-4 text-center">
          <p className="text-text-muted text-[10px] uppercase tracking-wider">Freeze left</p>
          <p className="text-white text-2xl font-medium mt-2">{profile?.streak_freeze_count ?? 0}</p>
        </Card>
      </div>

      <Card>
        <p className="text-text-secondary text-sm">STREAK FREEZE — {profile?.streak_freeze_count ?? 0} day protection</p>
        <p className="text-text-muted text-xs mt-2">Auto-used if you miss a day. Earn more by completing weekly challenges.</p>
      </Card>
    </div>
  );
}
