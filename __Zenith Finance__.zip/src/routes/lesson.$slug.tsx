import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { PrimaryButton, SegmentBar, Confetti } from "@/components/ui-bw";
import { advanceStreak, awardXP, maybeAwardBadge, setMasteryAtLeast } from "@/lib/finai";

export const Route = createFileRoute("/lesson/$slug")({
  component: LessonPlayer,
});

function LessonPlayer() {
  const { slug } = Route.useParams();
  const { session } = useAuth();
  const nav = useNavigate();
  const [lesson, setLesson] = useState<any>(null);
  const [idx, setIdx] = useState(0);
  const [done, setDone] = useState(false);
  const [showExit, setShowExit] = useState(false);

  useEffect(() => {
    (async () => {
      const { data: l } = await supabase.from("lessons").select("*").eq("slug", slug).maybeSingle();
      if (!l || !session) return;
      setLesson(l);
      const { data: p } = await supabase.from("user_lesson_progress").select("*").eq("user_id", session.user.id).eq("lesson_id", l.id).maybeSingle();
      if (p) {
        setIdx(p.card_index ?? 0);
        if (p.status === "available") {
          await supabase.from("user_lesson_progress").update({ status: "in_progress" }).eq("id", p.id);
        }
      } else {
        await supabase.from("user_lesson_progress").insert({ user_id: session.user.id, lesson_id: l.id, status: "in_progress", card_index: 0 });
      }
    })();
  }, [slug, session]);

  const cards = lesson?.cards ?? [];
  const total = cards.length;

  const next = async () => {
    if (!lesson || !session) return;
    const newIdx = idx + 1;
    if (newIdx >= total) {
      await supabase.from("user_lesson_progress").update({
        status: "completed", card_index: total, completed_at: new Date().toISOString(),
      }).eq("user_id", session.user.id).eq("lesson_id", lesson.id);
      await awardXP(session.user.id, lesson.xp_reward, "lesson", lesson.id);
      await advanceStreak(session.user.id);
      if (lesson.concept_id) await setMasteryAtLeast(session.user.id, lesson.concept_id, 2);
      await maybeAwardBadge(session.user.id, "first-lesson");
      setDone(true);
    } else {
      setIdx(newIdx);
      await supabase.from("user_lesson_progress").update({ card_index: newIdx }).eq("user_id", session.user.id).eq("lesson_id", lesson.id);
    }
  };

  if (!lesson) return <div className="min-h-screen bg-black flex items-center justify-center text-text-muted text-xs uppercase">Loading…</div>;

  if (done) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center px-6 relative">
        <Confetti />
        <p className="text-white text-5xl font-medium">+{lesson.xp_reward} XP</p>
        <p className="text-text-secondary mt-3">Lesson complete</p>
        <div className="mt-10 w-full max-w-sm space-y-3">
          <PrimaryButton onClick={() => nav({ to: "/home" })}>Continue →</PrimaryButton>
          <button onClick={() => nav({ to: "/home" })} className="text-text-secondary text-sm w-full text-center">Back to home</button>
        </div>
      </div>
    );
  }

  const card = cards[idx];
  const isLast = idx === total - 1;

  return (
    <div className="min-h-screen bg-black flex flex-col">
      <div className="flex items-center gap-3 px-4 pt-4">
        <button onClick={() => setShowExit(true)} className="w-8 h-8 flex items-center justify-center text-text-secondary">✕</button>
        <SegmentBar total={total} current={idx + 1} />
        <span className="text-[10px] text-text-muted">+{lesson.xp_reward} XP</span>
      </div>

      <div className="flex-1 px-4 py-6 flex">
        <div className="bg-surface-1 border border-border-default rounded-[16px] p-6 w-full flex flex-col">
          <p className="text-[10px] uppercase tracking-wider text-text-muted">{lesson.title}</p>
          <h2 className="text-xl font-medium mt-3 text-white">{card?.title}</h2>
          <p className="text-text-secondary mt-4 leading-[1.7]">{card?.body}</p>
          {card?.visual_hint && (
            <div className="mt-6 bg-surface-2 border border-border-default rounded-[12px] p-4 text-text-secondary text-sm font-mono">
              {card.visual_hint}
            </div>
          )}
        </div>
      </div>

      <div className="px-4 pb-6 space-y-2">
        <PrimaryButton onClick={next}>{isLast ? "Complete lesson →" : "Tap to continue"}</PrimaryButton>
        <button onClick={() => setShowExit(true)} className="text-text-faint text-xs w-full">exit lesson</button>
      </div>

      {showExit && (
        <div className="fixed inset-0 bg-black/95 flex items-center justify-center px-6 z-50">
          <div className="text-center max-w-sm">
            <p className="text-white text-xl font-medium">Exit lesson?</p>
            <p className="text-text-secondary mt-2 text-sm">Your progress is saved. You can resume any time.</p>
            <div className="mt-8 space-y-3">
              <PrimaryButton onClick={() => nav({ to: "/home" })}>Exit</PrimaryButton>
              <button onClick={() => setShowExit(false)} className="w-full h-11 border border-white rounded-[8px] text-white font-medium">Keep learning</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
