import type { ButtonHTMLAttributes, ReactNode } from "react";

export function Card({ children, className = "", border = "default" }: { children: ReactNode; className?: string; border?: "default" | "strong" | "white" }) {
  const b = border === "white" ? "border-white" : border === "strong" ? "border-border-strong" : "border-border-default";
  return <div className={`bg-surface-1 border ${b} rounded-[12px] p-5 ${className}`}>{children}</div>;
}

export function PrimaryButton({ children, className = "", ...props }: ButtonHTMLAttributes<HTMLButtonElement> & { children: ReactNode }) {
  return (
    <button
      {...props}
      className={`bg-white text-black rounded-[8px] h-11 px-5 font-medium w-full disabled:opacity-40 ${className}`}
    >
      {children}
    </button>
  );
}

export function GhostButton({ children, className = "", ...props }: ButtonHTMLAttributes<HTMLButtonElement> & { children: ReactNode }) {
  return (
    <button
      {...props}
      className={`bg-transparent border border-white text-white rounded-[8px] h-11 px-5 font-medium w-full ${className}`}
    >
      {children}
    </button>
  );
}

export function ProgressBar({ value, max = 100 }: { value: number; max?: number }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <div className="h-1.5 bg-border-default rounded-full overflow-hidden">
      <div className="h-full bg-white transition-all" style={{ width: `${pct}%` }} />
    </div>
  );
}

export function SegmentBar({ total, current }: { total: number; current: number }) {
  return (
    <div className="flex gap-1 flex-1">
      {Array.from({ length: total }).map((_, i) => (
        <div key={i} className={`h-1.5 flex-1 rounded-full ${i < current ? "bg-white" : "bg-border-default"}`} />
      ))}
    </div>
  );
}

export function Tag({ children }: { children: ReactNode }) {
  return <span className="text-[10px] uppercase tracking-wider text-text-muted">{children}</span>;
}

export function Chip({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex items-center text-xs px-2.5 py-1 rounded-[6px] bg-surface-1 border border-border-strong text-text-primary">
      {children}
    </span>
  );
}

export function Confetti() {
  const bits = Array.from({ length: 36 });
  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden">
      {bits.map((_, i) => (
        <span
          key={i}
          className="confetti-bit"
          style={{
            left: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 0.4}s`,
            animationDuration: `${1.2 + Math.random() * 0.8}s`,
            transform: `rotate(${Math.random() * 360}deg)`,
          }}
        />
      ))}
    </div>
  );
}
