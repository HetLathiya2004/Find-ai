import type { ReactNode } from "react";
import { Link, useRouterState, useNavigate } from "@tanstack/react-router";
import { Home, BookOpen, Dumbbell, Newspaper, User } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { useEffect } from "react";

const tabs = [
  { to: "/home", label: "Home", icon: Home },
  { to: "/learn", label: "Learn", icon: BookOpen },
  { to: "/practice", label: "Practice", icon: Dumbbell },
  { to: "/news", label: "News", icon: Newspaper },
  { to: "/profile", label: "Profile", icon: User },
] as const;

export default function AppShell({ children }: { children: ReactNode }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const { session, profile, loading } = useAuth();
  const nav = useNavigate();

  useEffect(() => {
    if (loading) return;
    if (!session) nav({ to: "/auth" });
    else if (profile && !profile.goal) nav({ to: "/onboarding" });
  }, [loading, session, profile, nav]);

  return (
    <div className="min-h-screen bg-bg text-text-primary flex flex-col">
      <main className="flex-1 pb-20 max-w-2xl w-full mx-auto px-4 pt-6">{children}</main>
      <nav className="fixed bottom-0 left-0 right-0 bg-bg border-t border-border-default">
        <div className="max-w-2xl mx-auto grid grid-cols-5">
          {tabs.map((t) => {
            const active = path === t.to || path.startsWith(t.to + "/");
            const Icon = t.icon;
            return (
              <Link
                key={t.to}
                to={t.to}
                className="flex flex-col items-center justify-center py-3 gap-1"
              >
                <Icon size={20} className={active ? "text-text-primary" : "text-text-muted"} />
                <span className={`text-[10px] ${active ? "text-text-primary" : "text-text-muted"}`}>{t.label}</span>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}

export function PageHeader({ title, right }: { title: string; right?: ReactNode }) {
  return (
    <div className="flex items-center justify-between mb-6">
      <h1 className="text-2xl font-medium text-text-primary">{title}</h1>
      {right}
    </div>
  );
}
